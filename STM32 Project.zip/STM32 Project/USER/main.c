#include "led.h"
#include "delay.h"
#include "sys.h"


//ALIENTEK miniSTM32������ʵ��1
//������ʵ��  
//����֧�֣�www.openedv.com
//�������������ӿƼ����޹�˾

typedef struct LED_Info_st{
    
    uint8_t led_id;
    uint8_t led_sta;
    void (*led_action)(void);

}LED_Info_st;

//*p++;

//p[1] 


void SysTick_Init(void)
{
    if(SysTick_Config( SystemCoreClock / 10))  // 100ms
    {
        while(1);
    }
    
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
}

uint8_t flag = 0;

void SysTick_Handler(void)
{
    flag = 1;  
}

void LED1_Process(void)
{
    static int cnt1;
    static uint8_t status = 0;
    
    cnt1 ++;
    if(cnt1 >= 5)
    {
        cnt1 = 0;
        ((status = !status)== 0) ? (GPIO_ResetBits(GPIOA,GPIO_Pin_8)) : (GPIO_SetBits(GPIOA,GPIO_Pin_8));
    } 
}

void LED2_Process(void)
{
    static int cnt2;
    static uint8_t status1 = 0;
    
    cnt2 ++;
    if(cnt2 >= 10)
    {
        cnt2 = 0;
        //status1 = !status1;
        ((status1 = !status1)== 0) ? (GPIO_ResetBits(GPIOD,GPIO_Pin_2)) : (GPIO_SetBits(GPIOD,GPIO_Pin_2));
    } 
}

 int main(void)
 {	
	//delay_init();	    // ��ʱ������ʼ��	  
	LED_Init();		  	// ��ʼ����LED���ӵ�Ӳ���ӿ�
     
     
    SysTick_Init();
    NVIC_Configuration();
     
	while(1)
	{
//		GPIO_ResetBits(GPIOA,GPIO_Pin_8); // LED0�����
//		GPIO_SetBits(GPIOD,GPIO_Pin_2);   // LED1�����
//		delay_ms(300);
//        
//		GPIO_SetBits(GPIOA,GPIO_Pin_8);   // LED0�����
//		GPIO_ResetBits(GPIOD,GPIO_Pin_2); // LED1�����
//		delay_ms(300);
        
        if(flag)
        {
            flag =0;
            LED1_Process();
            LED2_Process();
        }
	}
 }

